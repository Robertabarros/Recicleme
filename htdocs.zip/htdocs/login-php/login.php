<?php
session_start();
include('conexao.php');

if(empty($_POST['emailUsuario']) || empty($_POST['senhaUsuario'])) {
	header('Location: index.php');
	exit();
}

$emailUsuario = mysqli_real_escape_string($conexao,trim($_POST['emailUsuario']));
$senhaUsuario = mysqli_real_escape_string($conexao, trim($_POST['senhaUsuario']));

$query = "select nomeUsuario from users where emailUsuario = '{$emailUsuario}' and senhaUsuario = md5('{$senhaUsuario}')";

$result = mysqli_query($conexao, $query);

$row = mysqli_num_rows($result);

if($row == 1) {
	$usuario_bd = mysqli_fetch_assoc($result);
	$_SESSION['nomeUsuario'] = $usuario_bd['nomeUsuario'];
	header('Location: painel.php');
	exit();
} else {
	$_SESSION['nao_autenticado'] = true;
	header('Location: index.php');
	exit();
}