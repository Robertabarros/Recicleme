<?php
session_start();
include("conexao.php");

$nomeUsuario = mysqli_real_escape_string($conexao, trim($_POST['nomeUsuario']));
$emailUsuario = mysqli_real_escape_string($conexao, trim($_POST['emailUsuario']));
$senhaUsuario = mysqli_real_escape_string($conexao, trim(md5($_POST['senhaUsuario'])));

$telefoneUsuario = mysqli_real_escape_string($conexao, trim($_POST['telefoneUsuario']));
$cepUsuario = mysqli_real_escape_string($conexao, trim($_POST['cepUsuario']));
$enderecoUsuario = mysqli_real_escape_string($conexao, trim($_POST['enderecoUsuario']));

$sql = "select count(*) as total from users where emailUsuario = '$emailUsuario'";
$result = mysqli_query($conexao, $sql);
$row = mysqli_fetch_assoc($result);

if($row['total'] == 1) {
	$_SESSION['usuario_existe'] = true;
	header('Location: cadastro.php');
	exit;
}

$sql = "INSERT INTO users (nomeUsuario, emailUsuario, senhaUsuario, telefoneUsuario, cepUsuario, enderecoUsuario, data_cadastro) VALUES ('$nomeUsuario', '$emailUsuario', '$senhaUsuario','$telefoneUsuario', '$cepUsuario', '$enderecoUsuario',  NOW())";

if($conexao->query($sql) === TRUE) {
	$_SESSION['status_cadastro'] = true;
}

$conexao->close();

header('Location: cadastro.php');
exit;
?>