<?php
session_start();
include("conexao.php");

$tituloPost = mysqli_real_escape_string($conexao, trim($_POST['tituloPost']));
$filtroPost = mysqli_real_escape_string($conexao, trim($_POST['filtroPost']));
$categoriaPost = mysqli_real_escape_string($conexao, trim($_POST['categoriaPost']));
$materialPost = mysqli_real_escape_string($conexao, trim($_POST['materialPost']));
$descricaoPost = mysqli_real_escape_string($conexao, trim($_POST['descricaoPost']));

$imagem = mysqli_real_escape_string($conexao, trim($_POST['imagem'])); 

// $query = "select idPost from post";
// $result = mysqli_query($conexao, $query);






$sql = "INSERT INTO post (tituloPost, filtroPost, categoriaPost, materialPost, descricaoPost, imagem) 
VALUES ('$tituloPost', '$filtroPost', '$categoriaPost','$materialPost', '$descricaoPost', '$imagem')";
$result = mysqli_query($conexao, $sql);
if (mysqli_insert_id($conexao)) {
    $mensagem =  '<div class="alert alert-success">
    Post cadastrado com sucesso!
    </div>';
    $_SESSION['msg'] = $mensagem;
    header("Location: publiSustent.php");
} else{
    $mensagem =  '<div class="alert alert-danger">
    Post não cadastrado, favor preencher todos os campos!
    </div>';
    $_SESSION['msg'] = $mensagem;
    header("Location: publiSustent.php");
}

?>