<?php include('trancar.php'); ?>
<p>
	Se voc� est� vendo este conte�do � porque voc� tem acesso � p�gina
</p>
<p>
	<?php include('menu.php'); ?>
</p>