		<div class="clear"></div>

		</div> <!-- Fim da div#conteudo -->
		<div id="rodape" class="nao_imprimir">
  			<p>Controle de Estoque &copy; 2009</p>
		</div>
	</div> <!-- Fim da div#tudo -->