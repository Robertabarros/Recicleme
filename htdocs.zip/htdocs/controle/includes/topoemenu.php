	<div id="tudo">
		<div id="conteudo">
			<div id="topo">
				<h1>. . : : <i>Controle de Estoque &raquo; DSE</i> : : . .</h1>
				<p id="emitido"><?php echo "Emitido em: ".date("d-m-Y").""; ?></p>
			</div>
            <div id="menu">
				<ul id="primary-nav">
  					<li><a href="index.php">Home</a></li>
  					<li class="menuparent"><a href="#">Cadastrar</a> 
   					<ul>
      					<li><a href="cad_destino.php">Destino</a></li>
      					<li><a href="cad_fornecedor.php">Fornecedor</a></li>
      					<li><a href="cad_grupo.php">Grupo</a></li>
      					<li><a href="cad_produto.php">Produto</a></li>
      					<li><a href="cad_unidade.php">Unidade</a></li>
    					</ul>
					</li>
  				
  				<li class="menuparent"><a href="#">Controle</a> 
   				<ul>
      				<li><a href="entrada.php">Entrada</a></li>
      				<li><a href="saida.php">Saida</a></li>
      				<li><a href="ajuste.php">Ajustes</a></li>
					</ul>
				</li>
  				<li class="menuparent"><a href="#">Tabelas</a> 
   				<ul>
      				<li><a href="destinos.php">Destino</a></li>
      				<li><a href="fornecedores.php">Fornecedor</a></li>
      				<li><a href="grupos.php">Grupo</a></li>
      				<li><a href="produtos.php">Produto</a></li>
      				<li><a href="unidades.php">Unidade</a></li>
    				</ul>
  				</li>
  				<li class="menuparent"><a href="#">Relat&oacute;rios</a> 
   				<ul>
      				<li><a href="verentradas.php">Entradas</a></li>
      				<li><a href="versaidas.php">Saidas</a></li>
      				<li><a href="relatorio.php">Acumulados</a></li>
      				<li><a href="financeiro.php">Finan&ccedil;as</a></li>
					</ul>
				</li>
				<li><a href="login/logout.php">( Sair )</a></li>
			</ul>
         </div>
		
